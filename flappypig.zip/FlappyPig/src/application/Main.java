package application;

import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Main extends Application {
    public static boolean GAME_SET;

    private Parent createContent() {
        Pane root = new Pane();

        ImageView title = new ImageView(new Image(getClass().getResource("title.png").toExternalForm()));
        title.setFitWidth(178);
        title.setFitHeight(50);
        title.setLayoutX(200);
        title.setLayoutY(50);

        ImageView flappyPig = new ImageView(new Image(getClass().getResource("pig2.png").toExternalForm()));
        flappyPig.setFitWidth(50);
        flappyPig.setFitHeight(45);
        flappyPig.setLayoutX(260);
        flappyPig.setLayoutY(120);

        Rectangle bg = new Rectangle(600, 300);
        bg.setFill(Color.rgb(78,192,202));

        Text inst = new Text("Use the Space Bar or\nMouse Click to Start");
        inst.setFont(Font.font("Courier", FontWeight.EXTRA_BOLD, 25));
        inst.setFill(Color.WHITE);
        inst.setStroke(Color.BLACK);
        inst.setLayoutX(140);
        inst.setLayoutY(230);

        root.getChildren().addAll(bg, title, flappyPig, inst);
        return root;
    }

    public void startGame() {
        if (!GAME_SET) {
            GAME_SET = true;
            FlappyPig game = new FlappyPig();
            Stage st = new Stage();
            try {
                game.start(st);
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Scene scene = new Scene(createContent());
        scene.setOnKeyPressed(e -> {
            startGame();
        });
        scene.setOnMousePressed(e -> {
            startGame();
        });
        primaryStage.setTitle("Flappy Pig");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}