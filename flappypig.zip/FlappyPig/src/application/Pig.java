/**
 * 
 */
package application;
import application.Sprite ;

import java.util.ArrayList;
import java.util.Arrays;


public class Pig {
    private Sprite pig;
    private ArrayList<Sprite> flight = new ArrayList<>();
    private int currentPig = 0;
    private double locationX = 70;
    private double locationY = 200;
    private int PIG_WIDTH = 50;
    private int PIG_HEIGHT = 45;

    public Pig() {
        pig = new Sprite();
        pig.resizeImage("pig1.png", PIG_WIDTH, PIG_HEIGHT);
        pig.setPositionXY(locationX, locationY);
        setFlightAnimation();
    }

    public void setFlightAnimation() {
        Sprite pig2 = new Sprite();
        pig2.resizeImage("pig2.png", PIG_WIDTH, PIG_HEIGHT);
        pig2.setPositionXY(locationX, locationY);

        Sprite pig3 = new Sprite();
        pig3.resizeImage("pig1.png", PIG_WIDTH, PIG_HEIGHT);
        pig3.setPositionXY(locationX, locationY);

        Sprite pig4 = new Sprite();
        pig4.resizeImage("pig3.png", PIG_WIDTH, PIG_HEIGHT);
        pig4.setPositionXY(locationX, locationY);

        flight.addAll(Arrays.asList(pig, pig2, pig3, pig4));
    }

    public Sprite getPig() {
        return pig;
    }

    public Sprite animate() {
        if (currentPig == flight.size() - 1) {
            currentPig = 0;
        }

        return flight.get(currentPig++);
    }
}
